(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["firebase-app-firebase-auth-firebase-database-firebase-messaging"], {
    "9ab4": function(e, t, r) {
        "use strict";
        r.r(t),
        r.d(t, "__extends", (function() {
            return o
        }
        )),
        r.d(t, "__assign", (function() {
            return i
        }
        )),
        r.d(t, "__rest", (function() {
            return a
        }
        )),
        r.d(t, "__decorate", (function() {
            return s
        }
        )),
        r.d(t, "__param", (function() {
            return c
        }
        )),
        r.d(t, "__metadata", (function() {
            return u
        }
        )),
        r.d(t, "__awaiter", (function() {
            return f
        }
        )),
        r.d(t, "__generator", (function() {
            return l
        }
        )),
        r.d(t, "__exportStar", (function() {
            return h
        }
        )),
        r.d(t, "__values", (function() {
            return p
        }
        )),
        r.d(t, "__read", (function() {
            return d
        }
        )),
        r.d(t, "__spread", (function() {
            return v
        }
        )),
        r.d(t, "__spreadArrays", (function() {
            return b
        }
        )),
        r.d(t, "__await", (function() {
            return y
        }
        )),
        r.d(t, "__asyncGenerator", (function() {
            return _
        }
        )),
        r.d(t, "__asyncDelegator", (function() {
            return g
        }
        )),
        r.d(t, "__asyncValues", (function() {
            return m
        }
        )),
        r.d(t, "__makeTemplateObject", (function() {
            return E
        }
        )),
        r.d(t, "__importStar", (function() {
            return w
        }
        )),
        r.d(t, "__importDefault", (function() {
            return O
        }
        ));
        /*! *****************************************************************************
Copyright (c) Microsoft Corporation. All rights reserved.
Licensed under the Apache License, Version 2.0 (the "License"); you may not use
this file except in compliance with the License. You may obtain a copy of the
License at http://www.apache.org/licenses/LICENSE-2.0

THIS CODE IS PROVIDED ON AN *AS IS* BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION ANY IMPLIED
WARRANTIES OR CONDITIONS OF TITLE, FITNESS FOR A PARTICULAR PURPOSE,
MERCHANTABLITY OR NON-INFRINGEMENT.

See the Apache Version 2.0 License for specific language governing permissions
and limitations under the License.
***************************************************************************** */
        var n = function(e, t) {
            return n = Object.setPrototypeOf || {
                __proto__: []
            }instanceof Array && function(e, t) {
                e.__proto__ = t
            }
            || function(e, t) {
                for (var r in t)
                    t.hasOwnProperty(r) && (e[r] = t[r])
            }
            ,
            n(e, t)
        };
        function o(e, t) {
            function r() {
                this.constructor = e
            }
            n(e, t),
            e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype,
            new r)
        }
        var i = function() {
            return i = Object.assign || function(e) {
                for (var t, r = 1, n = arguments.length; r < n; r++)
                    for (var o in t = arguments[r],
                    t)
                        Object.prototype.hasOwnProperty.call(t, o) && (e[o] = t[o]);
                return e
            }
            ,
            i.apply(this, arguments)
        };
        function a(e, t) {
            var r = {};
            for (var n in e)
                Object.prototype.hasOwnProperty.call(e, n) && t.indexOf(n) < 0 && (r[n] = e[n]);
            if (null != e && "function" === typeof Object.getOwnPropertySymbols) {
                var o = 0;
                for (n = Object.getOwnPropertySymbols(e); o < n.length; o++)
                    t.indexOf(n[o]) < 0 && Object.prototype.propertyIsEnumerable.call(e, n[o]) && (r[n[o]] = e[n[o]])
            }
            return r
        }
        function s(e, t, r, n) {
            var o, i = arguments.length, a = i < 3 ? t : null === n ? n = Object.getOwnPropertyDescriptor(t, r) : n;
            if ("object" === typeof Reflect && "function" === typeof Reflect.decorate)
                a = Reflect.decorate(e, t, r, n);
            else
                for (var s = e.length - 1; s >= 0; s--)
                    (o = e[s]) && (a = (i < 3 ? o(a) : i > 3 ? o(t, r, a) : o(t, r)) || a);
            return i > 3 && a && Object.defineProperty(t, r, a),
            a
        }
        function c(e, t) {
            return function(r, n) {
                t(r, n, e)
            }
        }
        function u(e, t) {
            if ("object" === typeof Reflect && "function" === typeof Reflect.metadata)
                return Reflect.metadata(e, t)
        }
        function f(e, t, r, n) {
            return new (r || (r = Promise))((function(o, i) {
                function a(e) {
                    try {
                        c(n.next(e))
                    } catch (t) {
                        i(t)
                    }
                }
                function s(e) {
                    try {
                        c(n["throw"](e))
                    } catch (t) {
                        i(t)
                    }
                }
                function c(e) {
                    e.done ? o(e.value) : new r((function(t) {
                        t(e.value)
                    }
                    )).then(a, s)
                }
                c((n = n.apply(e, t || [])).next())
            }
            ))
        }
        function l(e, t) {
            var r, n, o, i, a = {
                label: 0,
                sent: function() {
                    if (1 & o[0])
                        throw o[1];
                    return o[1]
                },
                trys: [],
                ops: []
            };
            return i = {
                next: s(0),
                throw: s(1),
                return: s(2)
            },
            "function" === typeof Symbol && (i[Symbol.iterator] = function() {
                return this
            }
            ),
            i;
            function s(e) {
                return function(t) {
                    return c([e, t])
                }
            }
            function c(i) {
                if (r)
                    throw new TypeError("Generator is already executing.");
                while (a)
                    try {
                        if (r = 1,
                        n && (o = 2 & i[0] ? n["return"] : i[0] ? n["throw"] || ((o = n["return"]) && o.call(n),
                        0) : n.next) && !(o = o.call(n, i[1])).done)
                            return o;
                        switch (n = 0,
                        o && (i = [2 & i[0], o.value]),
                        i[0]) {
                        case 0:
                        case 1:
                            o = i;
                            break;
                        case 4:
                            return a.label++,
                            {
                                value: i[1],
                                done: !1
                            };
                        case 5:
                            a.label++,
                            n = i[1],
                            i = [0];
                            continue;
                        case 7:
                            i = a.ops.pop(),
                            a.trys.pop();
                            continue;
                        default:
                            if (o = a.trys,
                            !(o = o.length > 0 && o[o.length - 1]) && (6 === i[0] || 2 === i[0])) {
                                a = 0;
                                continue
                            }
                            if (3 === i[0] && (!o || i[1] > o[0] && i[1] < o[3])) {
                                a.label = i[1];
                                break
                            }
                            if (6 === i[0] && a.label < o[1]) {
                                a.label = o[1],
                                o = i;
                                break
                            }
                            if (o && a.label < o[2]) {
                                a.label = o[2],
                                a.ops.push(i);
                                break
                            }
                            o[2] && a.ops.pop(),
                            a.trys.pop();
                            continue
                        }
                        i = t.call(e, a)
                    } catch (s) {
                        i = [6, s],
                        n = 0
                    } finally {
                        r = o = 0
                    }
                if (5 & i[0])
                    throw i[1];
                return {
                    value: i[0] ? i[1] : void 0,
                    done: !0
                }
            }
        }
        function h(e, t) {
            for (var r in e)
                t.hasOwnProperty(r) || (t[r] = e[r])
        }
        function p(e) {
            var t = "function" === typeof Symbol && e[Symbol.iterator]
              , r = 0;
            return t ? t.call(e) : {
                next: function() {
                    return e && r >= e.length && (e = void 0),
                    {
                        value: e && e[r++],
                        done: !e
                    }
                }
            }
        }
        function d(e, t) {
            var r = "function" === typeof Symbol && e[Symbol.iterator];
            if (!r)
                return e;
            var n, o, i = r.call(e), a = [];
            try {
                while ((void 0 === t || t-- > 0) && !(n = i.next()).done)
                    a.push(n.value)
            } catch (s) {
                o = {
                    error: s
                }
            } finally {
                try {
                    n && !n.done && (r = i["return"]) && r.call(i)
                } finally {
                    if (o)
                        throw o.error
                }
            }
            return a
        }
        function v() {
            for (var e = [], t = 0; t < arguments.length; t++)
                e = e.concat(d(arguments[t]));
            return e
        }
        function b() {
            for (var e = 0, t = 0, r = arguments.length; t < r; t++)
                e += arguments[t].length;
            var n = Array(e)
              , o = 0;
            for (t = 0; t < r; t++)
                for (var i = arguments[t], a = 0, s = i.length; a < s; a++,
                o++)
                    n[o] = i[a];
            return n
        }
        function y(e) {
            return this instanceof y ? (this.v = e,
            this) : new y(e)
        }
        function _(e, t, r) {
            if (!Symbol.asyncIterator)
                throw new TypeError("Symbol.asyncIterator is not defined.");
            var n, o = r.apply(e, t || []), i = [];
            return n = {},
            a("next"),
            a("throw"),
            a("return"),
            n[Symbol.asyncIterator] = function() {
                return this
            }
            ,
            n;
            function a(e) {
                o[e] && (n[e] = function(t) {
                    return new Promise((function(r, n) {
                        i.push([e, t, r, n]) > 1 || s(e, t)
                    }
                    ))
                }
                )
            }
            function s(e, t) {
                try {
                    c(o[e](t))
                } catch (r) {
                    l(i[0][3], r)
                }
            }
            function c(e) {
                e.value instanceof y ? Promise.resolve(e.value.v).then(u, f) : l(i[0][2], e)
            }
            function u(e) {
                s("next", e)
            }
            function f(e) {
                s("throw", e)
            }
            function l(e, t) {
                e(t),
                i.shift(),
                i.length && s(i[0][0], i[0][1])
            }
        }
        function g(e) {
            var t, r;
            return t = {},
            n("next"),
            n("throw", (function(e) {
                throw e
            }
            )),
            n("return"),
            t[Symbol.iterator] = function() {
                return this
            }
            ,
            t;
            function n(n, o) {
                t[n] = e[n] ? function(t) {
                    return (r = !r) ? {
                        value: y(e[n](t)),
                        done: "return" === n
                    } : o ? o(t) : t
                }
                : o
            }
        }
        function m(e) {
            if (!Symbol.asyncIterator)
                throw new TypeError("Symbol.asyncIterator is not defined.");
            var t, r = e[Symbol.asyncIterator];
            return r ? r.call(e) : (e = "function" === typeof p ? p(e) : e[Symbol.iterator](),
            t = {},
            n("next"),
            n("throw"),
            n("return"),
            t[Symbol.asyncIterator] = function() {
                return this
            }
            ,
            t);
            function n(r) {
                t[r] = e[r] && function(t) {
                    return new Promise((function(n, i) {
                        t = e[r](t),
                        o(n, i, t.done, t.value)
                    }
                    ))
                }
            }
            function o(e, t, r, n) {
                Promise.resolve(n).then((function(t) {
                    e({
                        value: t,
                        done: r
                    })
                }
                ), t)
            }
        }
        function E(e, t) {
            return Object.defineProperty ? Object.defineProperty(e, "raw", {
                value: t
            }) : e.raw = t,
            e
        }
        function w(e) {
            if (e && e.__esModule)
                return e;
            var t = {};
            if (null != e)
                for (var r in e)
                    Object.hasOwnProperty.call(e, r) && (t[r] = e[r]);
            return t.default = e,
            t
        }
        function O(e) {
            return e && e.__esModule ? e : {
                default: e
            }
        }
    },
    abfd: function(e, t, r) {
        "use strict";
        r.r(t),
        r.d(t, "LogLevel", (function() {
            return n
        }
        )),
        r.d(t, "Logger", (function() {
            return s
        }
        )),
        r.d(t, "setLogLevel", (function() {
            return c
        }
        ));
        /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        var n, o = [];
        (function(e) {
            e[e["DEBUG"] = 0] = "DEBUG",
            e[e["VERBOSE"] = 1] = "VERBOSE",
            e[e["INFO"] = 2] = "INFO",
            e[e["WARN"] = 3] = "WARN",
            e[e["ERROR"] = 4] = "ERROR",
            e[e["SILENT"] = 5] = "SILENT"
        }
        )(n || (n = {}));
        var i = n.INFO
          , a = function(e, t) {
            for (var r = [], o = 2; o < arguments.length; o++)
                r[o - 2] = arguments[o];
            if (!(t < e.logLevel)) {
                var i = (new Date).toISOString();
                switch (t) {
                case n.DEBUG:
                    console.log.apply(console, ["[" + i + "]  " + e.name + ":"].concat(r));
                    break;
                case n.VERBOSE:
                    console.log.apply(console, ["[" + i + "]  " + e.name + ":"].concat(r));
                    break;
                case n.INFO:
                    console.info.apply(console, ["[" + i + "]  " + e.name + ":"].concat(r));
                    break;
                case n.WARN:
                    console.warn.apply(console, ["[" + i + "]  " + e.name + ":"].concat(r));
                    break;
                case n.ERROR:
                    console.error.apply(console, ["[" + i + "]  " + e.name + ":"].concat(r));
                    break;
                default:
                    throw new Error("Attempted to log a message with an invalid logType (value: " + t + ")")
                }
            }
        }
          , s = function() {
            function e(e) {
                this.name = e,
                this._logLevel = i,
                this._logHandler = a,
                o.push(this)
            }
            return Object.defineProperty(e.prototype, "logLevel", {
                get: function() {
                    return this._logLevel
                },
                set: function(e) {
                    if (!(e in n))
                        throw new TypeError("Invalid value assigned to `logLevel`");
                    this._logLevel = e
                },
                enumerable: !0,
                configurable: !0
            }),
            Object.defineProperty(e.prototype, "logHandler", {
                get: function() {
                    return this._logHandler
                },
                set: function(e) {
                    if ("function" !== typeof e)
                        throw new TypeError("Value assigned to `logHandler` must be a function");
                    this._logHandler = e
                },
                enumerable: !0,
                configurable: !0
            }),
            e.prototype.debug = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this._logHandler.apply(this, [this, n.DEBUG].concat(e))
            }
            ,
            e.prototype.log = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this._logHandler.apply(this, [this, n.VERBOSE].concat(e))
            }
            ,
            e.prototype.info = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this._logHandler.apply(this, [this, n.INFO].concat(e))
            }
            ,
            e.prototype.warn = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this._logHandler.apply(this, [this, n.WARN].concat(e))
            }
            ,
            e.prototype.error = function() {
                for (var e = [], t = 0; t < arguments.length; t++)
                    e[t] = arguments[t];
                this._logHandler.apply(this, [this, n.ERROR].concat(e))
            }
            ,
            e
        }();
        /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        function c(e) {
            o.forEach((function(t) {
                t.logLevel = e
            }
            ))
        }
    },
    c23d: function(e, t, r) {
        "use strict";
        Object.defineProperty(t, "__esModule", {
            value: !0
        });
        var n, o = r("9ab4"), i = r("cd51"), a = r("abfd"), s = (n = {},
        n["no-app"] = "No Firebase App '{$appName}' has been created - call Firebase App.initializeApp()",
        n["bad-app-name"] = "Illegal App name: '{$appName}",
        n["duplicate-app"] = "Firebase App named '{$appName}' already exists",
        n["app-deleted"] = "Firebase App named '{$appName}' already deleted",
        n["invalid-app-argument"] = "firebase.{$appName}() takes either no argument or a Firebase App instance.",
        n), c = new i.ErrorFactory("app","Firebase",s), u = "[DEFAULT]", f = [], l = function() {
            function e(e, t, r) {
                this.firebase_ = r,
                this.isDeleted_ = !1,
                this.services_ = {},
                this.name_ = t.name,
                this.automaticDataCollectionEnabled_ = t.automaticDataCollectionEnabled || !1,
                this.options_ = i.deepCopy(e),
                this.INTERNAL = {
                    getUid: function() {
                        return null
                    },
                    getToken: function() {
                        return Promise.resolve(null)
                    },
                    addAuthTokenListener: function(e) {
                        f.push(e),
                        setTimeout((function() {
                            return e(null)
                        }
                        ), 0)
                    },
                    removeAuthTokenListener: function(e) {
                        f = f.filter((function(t) {
                            return t !== e
                        }
                        ))
                    }
                }
            }
            return Object.defineProperty(e.prototype, "automaticDataCollectionEnabled", {
                get: function() {
                    return this.checkDestroyed_(),
                    this.automaticDataCollectionEnabled_
                },
                set: function(e) {
                    this.checkDestroyed_(),
                    this.automaticDataCollectionEnabled_ = e
                },
                enumerable: !0,
                configurable: !0
            }),
            Object.defineProperty(e.prototype, "name", {
                get: function() {
                    return this.checkDestroyed_(),
                    this.name_
                },
                enumerable: !0,
                configurable: !0
            }),
            Object.defineProperty(e.prototype, "options", {
                get: function() {
                    return this.checkDestroyed_(),
                    this.options_
                },
                enumerable: !0,
                configurable: !0
            }),
            e.prototype.delete = function() {
                var e = this;
                return new Promise((function(t) {
                    e.checkDestroyed_(),
                    t()
                }
                )).then((function() {
                    e.firebase_.INTERNAL.removeApp(e.name_);
                    for (var t = [], r = 0, n = Object.keys(e.services_); r < n.length; r++)
                        for (var o = n[r], i = 0, a = Object.keys(e.services_[o]); i < a.length; i++) {
                            var s = a[i];
                            t.push(e.services_[o][s])
                        }
                    return Promise.all(t.filter((function(e) {
                        return "INTERNAL"in e
                    }
                    )).map((function(e) {
                        return e.INTERNAL.delete()
                    }
                    )))
                }
                )).then((function() {
                    e.isDeleted_ = !0,
                    e.services_ = {}
                }
                ))
            }
            ,
            e.prototype._getService = function(e, t) {
                if (void 0 === t && (t = u),
                this.checkDestroyed_(),
                this.services_[e] || (this.services_[e] = {}),
                !this.services_[e][t]) {
                    var r = t !== u ? t : void 0
                      , n = this.firebase_.INTERNAL.factories[e](this, this.extendApp.bind(this), r);
                    this.services_[e][t] = n
                }
                return this.services_[e][t]
            }
            ,
            e.prototype._removeServiceInstance = function(e, t) {
                void 0 === t && (t = u),
                this.services_[e] && this.services_[e][t] && delete this.services_[e][t]
            }
            ,
            e.prototype.extendApp = function(e) {
                var t = this;
                i.deepExtend(this, e),
                e.INTERNAL && e.INTERNAL.addAuthTokenListener && (f.forEach((function(e) {
                    t.INTERNAL.addAuthTokenListener(e)
                }
                )),
                f = [])
            }
            ,
            e.prototype.checkDestroyed_ = function() {
                if (this.isDeleted_)
                    throw c.create("app-deleted", {
                        appName: this.name_
                    })
            }
            ,
            e
        }();
        l.prototype.name && l.prototype.options || l.prototype.delete || console.log("dc");
        var h = "6.6.0"
          , p = new a.Logger("@firebase/app");
        /**
 * @license
 * Copyright 2019 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        /**
 * @license
 * Copyright 2019 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        function d(e) {
            var t = {}
              , r = {}
              , n = {}
              , o = {
                __esModule: !0,
                initializeApp: f,
                app: s,
                apps: null,
                SDK_VERSION: h,
                INTERNAL: {
                    registerService: d,
                    removeApp: a,
                    factories: r,
                    useAsService: b
                }
            };
            function a(e) {
                var r = t[e];
                v(r, "delete"),
                delete t[e]
            }
            function s(e) {
                if (e = e || u,
                !i.contains(t, e))
                    throw c.create("no-app", {
                        appName: e
                    });
                return t[e]
            }
            function f(r, n) {
                if (void 0 === n && (n = {}),
                "object" !== typeof n || null === n) {
                    var a = n;
                    n = {
                        name: a
                    }
                }
                var s = n;
                void 0 === s.name && (s.name = u);
                var f = s.name;
                if ("string" !== typeof f || !f)
                    throw c.create("bad-app-name", {
                        appName: String(f)
                    });
                if (i.contains(t, f))
                    throw c.create("duplicate-app", {
                        appName: f
                    });
                var l = new e(r,s,o);
                return t[f] = l,
                v(l, "create"),
                l
            }
            function l() {
                return Object.keys(t).map((function(e) {
                    return t[e]
                }
                ))
            }
            function d(t, a, u, f, h) {
                if (void 0 === h && (h = !1),
                r[t])
                    return p.debug("There were multiple attempts to register service " + t + "."),
                    o[t];
                function d(e) {
                    if (void 0 === e && (e = s()),
                    "function" !== typeof e[t])
                        throw c.create("invalid-app-argument", {
                            appName: t
                        });
                    return e[t]()
                }
                return r[t] = a,
                f && (n[t] = f,
                l().forEach((function(e) {
                    f("create", e)
                }
                ))),
                void 0 !== u && i.deepExtend(d, u),
                o[t] = d,
                e.prototype[t] = function() {
                    for (var e = [], r = 0; r < arguments.length; r++)
                        e[r] = arguments[r];
                    var n = this._getService.bind(this, t);
                    return n.apply(this, h ? e : [])
                }
                ,
                d
            }
            function v(e, t) {
                for (var o = 0, i = Object.keys(r); o < i.length; o++) {
                    var a = i[o]
                      , s = b(e, a);
                    if (null === s)
                        return;
                    n[s] && n[s](t, e)
                }
            }
            function b(e, t) {
                if ("serverAuth" === t)
                    return null;
                var r = t;
                return r
            }
            return (o["default"] = o,
            Object.defineProperty(o, "apps", {
                get: l
            }),
            s["App"] = e,
            o)
        }
        /**
 * @license
 * Copyright 2019 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        function v() {
            var e = d(l);
            function t(t) {
                i.deepExtend(e, t)
            }
            return e.INTERNAL = o.__assign({}, e.INTERNAL, {
                createFirebaseNamespace: v,
                extendNamespace: t,
                createSubscribe: i.createSubscribe,
                ErrorFactory: i.ErrorFactory,
                deepExtend: i.deepExtend
            }),
            e
        }
        /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
        if (i.isBrowser() && void 0 !== self.firebase) {
            p.warn("\n    Warning: Firebase is already defined in the global scope. Please make sure\n    Firebase library is only loaded once.\n  ");
            var b = self.firebase.SDK_VERSION;
            b && b.indexOf("LITE") >= 0 && p.warn("\n    Warning: You are trying to load Firebase while using Firebase Performance standalone script.\n    You should load Firebase Performance with this instance of Firebase to avoid loading duplicate code.\n    ")
        }
        var y = v()
          , _ = y.initializeApp;
        y.initializeApp = function() {
            for (var e = [], t = 0; t < arguments.length; t++)
                e[t] = arguments[t];
            return i.isNode() && p.warn('\n      Warning: This is a browser-targeted Firebase bundle but it appears it is being\n      run in a Node environment.  If running in a Node environment, make sure you\n      are using the bundle specified by the "main" field in package.json.\n      \n      If you are using Webpack, you can specify "main" as the first item in\n      "resolve.mainFields":\n      https://webpack.js.org/configuration/resolve/#resolvemainfields\n      \n      If using Rollup, use the rollup-plugin-node-resolve plugin and specify "main"\n      as the first item in "mainFields", e.g. [\'main\', \'module\'].\n      https://github.com/rollup/rollup-plugin-node-resolve\n      '),
            _.apply(void 0, e)
        }
        ;
        var g = y;
        t.default = g,
        t.firebase = g
    },
    cd51: function(e, t, r) {
        "use strict";
        (function(e) {
            Object.defineProperty(t, "__esModule", {
                value: !0
            });
            var n = r("9ab4")
              , o = {
                NODE_CLIENT: !1,
                NODE_ADMIN: !1,
                SDK_VERSION: "${JSCORE_VERSION}"
            }
              , i = function(e, t) {
                if (!e)
                    throw a(t)
            }
              , a = function(e) {
                return new Error("Firebase Database (" + o.SDK_VERSION + ") INTERNAL ASSERT FAILED: " + e)
            }
              , s = function(e) {
                for (var t = [], r = 0, n = 0; n < e.length; n++) {
                    var o = e.charCodeAt(n);
                    o < 128 ? t[r++] = o : o < 2048 ? (t[r++] = o >> 6 | 192,
                    t[r++] = 63 & o | 128) : 55296 === (64512 & o) && n + 1 < e.length && 56320 === (64512 & e.charCodeAt(n + 1)) ? (o = 65536 + ((1023 & o) << 10) + (1023 & e.charCodeAt(++n)),
                    t[r++] = o >> 18 | 240,
                    t[r++] = o >> 12 & 63 | 128,
                    t[r++] = o >> 6 & 63 | 128,
                    t[r++] = 63 & o | 128) : (t[r++] = o >> 12 | 224,
                    t[r++] = o >> 6 & 63 | 128,
                    t[r++] = 63 & o | 128)
                }
                return t
            }
              , c = function(e) {
                var t = []
                  , r = 0
                  , n = 0;
                while (r < e.length) {
                    var o = e[r++];
                    if (o < 128)
                        t[n++] = String.fromCharCode(o);
                    else if (o > 191 && o < 224) {
                        var i = e[r++];
                        t[n++] = String.fromCharCode((31 & o) << 6 | 63 & i)
                    } else if (o > 239 && o < 365) {
                        i = e[r++];
                        var a = e[r++]
                          , s = e[r++]
                          , c = ((7 & o) << 18 | (63 & i) << 12 | (63 & a) << 6 | 63 & s) - 65536;
                        t[n++] = String.fromCharCode(55296 + (c >> 10)),
                        t[n++] = String.fromCharCode(56320 + (1023 & c))
                    } else {
                        i = e[r++],
                        a = e[r++];
                        t[n++] = String.fromCharCode((15 & o) << 12 | (63 & i) << 6 | 63 & a)
                    }
                }
                return t.join("")
            }
              , u = {
                byteToCharMap_: null,
                charToByteMap_: null,
                byteToCharMapWebSafe_: null,
                charToByteMapWebSafe_: null,
                ENCODED_VALS_BASE: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",
                get ENCODED_VALS() {
                    return this.ENCODED_VALS_BASE + "+/="
                },
                get ENCODED_VALS_WEBSAFE() {
                    return this.ENCODED_VALS_BASE + "-_."
                },
                HAS_NATIVE_SUPPORT: "function" === typeof atob,
                encodeByteArray: function(e, t) {
                    if (!Array.isArray(e))
                        throw Error("encodeByteArray takes an array as a parameter");
                    this.init_();
                    for (var r = t ? this.byteToCharMapWebSafe_ : this.byteToCharMap_, n = [], o = 0; o < e.length; o += 3) {
                        var i = e[o]
                          , a = o + 1 < e.length
                          , s = a ? e[o + 1] : 0
                          , c = o + 2 < e.length
                          , u = c ? e[o + 2] : 0
                          , f = i >> 2
                          , l = (3 & i) << 4 | s >> 4
                          , h = (15 & s) << 2 | u >> 6
                          , p = 63 & u;
                        c || (p = 64,
                        a || (h = 64)),
                        n.push(r[f], r[l], r[h], r[p])
                    }
                    return n.join("")
                },
                encodeString: function(e, t) {
                    return this.HAS_NATIVE_SUPPORT && !t ? btoa(e) : this.encodeByteArray(s(e), t)
                },
                decodeString: function(e, t) {
                    return this.HAS_NATIVE_SUPPORT && !t ? atob(e) : c(this.decodeStringToByteArray(e, t))
                },
                decodeStringToByteArray: function(e, t) {
                    this.init_();
                    for (var r = t ? this.charToByteMapWebSafe_ : this.charToByteMap_, n = [], o = 0; o < e.length; ) {
                        var i = r[e.charAt(o++)]
                          , a = o < e.length
                          , s = a ? r[e.charAt(o)] : 0;
                        ++o;
                        var c = o < e.length
                          , u = c ? r[e.charAt(o)] : 64;
                        ++o;
                        var f = o < e.length
                          , l = f ? r[e.charAt(o)] : 64;
                        if (++o,
                        null == i || null == s || null == u || null == l)
                            throw Error();
                        var h = i << 2 | s >> 4;
                        if (n.push(h),
                        64 !== u) {
                            var p = s << 4 & 240 | u >> 2;
                            if (n.push(p),
                            64 !== l) {
                                var d = u << 6 & 192 | l;
                                n.push(d)
                            }
                        }
                    }
                    return n
                },
                init_: function() {
                    if (!this.byteToCharMap_) {
                        this.byteToCharMap_ = {},
                        this.charToByteMap_ = {},
                        this.byteToCharMapWebSafe_ = {},
                        this.charToByteMapWebSafe_ = {};
                        for (var e = 0; e < this.ENCODED_VALS.length; e++)
                            this.byteToCharMap_[e] = this.ENCODED_VALS.charAt(e),
                            this.charToByteMap_[this.byteToCharMap_[e]] = e,
                            this.byteToCharMapWebSafe_[e] = this.ENCODED_VALS_WEBSAFE.charAt(e),
                            this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]] = e,
                            e >= this.ENCODED_VALS_BASE.length && (this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)] = e,
                            this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)] = e)
                    }
                }
            }
              , f = function(e) {
                var t = s(e);
                return u.encodeByteArray(t, !0)
            }
              , l = function(e) {
                try {
                    return u.decodeString(e, !0)
                } catch (t) {
                    console.error("base64Decode failed: ", t)
                }
                return null
            };
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            function h(e) {
                return p(void 0, e)
            }
            function p(e, t) {
                if (!(t instanceof Object))
                    return t;
                switch (t.constructor) {
                case Date:
                    var r = t;
                    return new Date(r.getTime());
                case Object:
                    void 0 === e && (e = {});
                    break;
                case Array:
                    e = [];
                    break;
                default:
                    return t
                }
                for (var n in t)
                    t.hasOwnProperty(n) && (e[n] = p(e[n], t[n]));
                return e
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var d = function() {
                function e() {
                    var e = this;
                    this.reject = function() {}
                    ,
                    this.resolve = function() {}
                    ,
                    this.promise = new Promise((function(t, r) {
                        e.resolve = t,
                        e.reject = r
                    }
                    ))
                }
                return e.prototype.wrapCallback = function(e) {
                    var t = this;
                    return function(r, n) {
                        r ? t.reject(r) : t.resolve(n),
                        "function" === typeof e && (t.promise.catch((function() {}
                        )),
                        1 === e.length ? e(r) : e(r, n))
                    }
                }
                ,
                e
            }();
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            function v() {
                return "undefined" !== typeof navigator && "string" === typeof navigator["userAgent"] ? navigator["userAgent"] : ""
            }
            function b() {
                return "undefined" !== typeof window && !!(window["cordova"] || window["phonegap"] || window["PhoneGap"]) && /ios|iphone|ipod|ipad|android|blackberry|iemobile/i.test(v())
            }
            function y() {
                try {
                    return "[object process]" === Object.prototype.toString.call(e.process)
                } catch (t) {
                    return !1
                }
            }
            function _() {
                return "object" === typeof self && self.self === self
            }
            function g() {
                return "object" === typeof navigator && "ReactNative" === navigator["product"]
            }
            function m() {
                return !0 === o.NODE_CLIENT || !0 === o.NODE_ADMIN
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var E = "FirebaseError"
              , w = function(e) {
                function t(r, n) {
                    var o = e.call(this, n) || this;
                    return o.code = r,
                    o.name = E,
                    Object.setPrototypeOf(o, t.prototype),
                    Error.captureStackTrace && Error.captureStackTrace(o, O.prototype.create),
                    o
                }
                return n.__extends(t, e),
                t
            }(Error)
              , O = function() {
                function e(e, t, r) {
                    this.service = e,
                    this.serviceName = t,
                    this.errors = r
                }
                return e.prototype.create = function(e) {
                    for (var t = [], r = 1; r < arguments.length; r++)
                        t[r - 1] = arguments[r];
                    for (var n = t[0] || {}, o = this.service + "/" + e, i = this.errors[e], a = i ? S(i, n) : "Error", s = this.serviceName + ": " + a + " (" + o + ").", c = new w(o,s), u = 0, f = Object.keys(n); u < f.length; u++) {
                        var l = f[u];
                        "_" !== l.slice(-1) && (l in c && console.warn('Overwriting FirebaseError base field "' + l + '" can cause unexpected behavior.'),
                        c[l] = n[l])
                    }
                    return c
                }
                ,
                e
            }();
            function S(e, t) {
                return e.replace(A, (function(e, r) {
                    var n = t[r];
                    return null != n ? n.toString() : "<" + r + "?>"
                }
                ))
            }
            var A = /\{\$([^}]+)}/g;
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            function N(e) {
                return JSON.parse(e)
            }
            function T(e) {
                return JSON.stringify(e)
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var C = function(e) {
                var t = {}
                  , r = {}
                  , n = {}
                  , o = "";
                try {
                    var i = e.split(".");
                    t = N(l(i[0]) || ""),
                    r = N(l(i[1]) || ""),
                    o = i[2],
                    n = r["d"] || {},
                    delete r["d"]
                } catch (a) {}
                return {
                    header: t,
                    claims: r,
                    data: n,
                    signature: o
                }
            }
              , D = function(e) {
                var t = C(e).claims
                  , r = Math.floor((new Date).getTime() / 1e3)
                  , n = 0
                  , o = 0;
                return "object" === typeof t && (t.hasOwnProperty("nbf") ? n = t["nbf"] : t.hasOwnProperty("iat") && (n = t["iat"]),
                o = t.hasOwnProperty("exp") ? t["exp"] : n + 86400),
                !!r && !!n && !!o && r >= n && r <= o
            }
              , k = function(e) {
                var t = C(e).claims;
                return "object" === typeof t && t.hasOwnProperty("iat") ? t["iat"] : null
            }
              , j = function(e) {
                var t = C(e)
                  , r = t.claims;
                return !!r && "object" === typeof r && r.hasOwnProperty("iat")
            }
              , R = function(e) {
                var t = C(e).claims;
                return "object" === typeof t && !0 === t["admin"]
            };
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            function P(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t)
            }
            function I(e, t) {
                return Object.prototype.hasOwnProperty.call(e, t) ? e[t] : void 0
            }
            function L(e) {
                for (var t in e)
                    if (Object.prototype.hasOwnProperty.call(e, t))
                        return !1;
                return !0
            }
            function x(e, t, r) {
                var n = {};
                for (var o in e)
                    Object.prototype.hasOwnProperty.call(e, o) && (n[o] = t.call(r, e[o], o, e));
                return n
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            function F(e) {
                for (var t = [], r = function(e, r) {
                    Array.isArray(r) ? r.forEach((function(r) {
                        t.push(encodeURIComponent(e) + "=" + encodeURIComponent(r))
                    }
                    )) : t.push(encodeURIComponent(e) + "=" + encodeURIComponent(r))
                }, n = 0, o = Object.entries(e); n < o.length; n++) {
                    var i = o[n]
                      , a = i[0]
                      , s = i[1];
                    r(a, s)
                }
                return t.length ? "&" + t.join("&") : ""
            }
            function B(e) {
                var t = {}
                  , r = e.replace(/^\?/, "").split("&");
                return r.forEach((function(e) {
                    if (e) {
                        var r = e.split("=");
                        t[r[0]] = r[1]
                    }
                }
                )),
                t
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var M = function() {
                function e() {
                    this.chain_ = [],
                    this.buf_ = [],
                    this.W_ = [],
                    this.pad_ = [],
                    this.inbuf_ = 0,
                    this.total_ = 0,
                    this.blockSize = 64,
                    this.pad_[0] = 128;
                    for (var e = 1; e < this.blockSize; ++e)
                        this.pad_[e] = 0;
                    this.reset()
                }
                return e.prototype.reset = function() {
                    this.chain_[0] = 1732584193,
                    this.chain_[1] = 4023233417,
                    this.chain_[2] = 2562383102,
                    this.chain_[3] = 271733878,
                    this.chain_[4] = 3285377520,
                    this.inbuf_ = 0,
                    this.total_ = 0
                }
                ,
                e.prototype.compress_ = function(e, t) {
                    t || (t = 0);
                    var r = this.W_;
                    if ("string" === typeof e)
                        for (var n = 0; n < 16; n++)
                            r[n] = e.charCodeAt(t) << 24 | e.charCodeAt(t + 1) << 16 | e.charCodeAt(t + 2) << 8 | e.charCodeAt(t + 3),
                            t += 4;
                    else
                        for (n = 0; n < 16; n++)
                            r[n] = e[t] << 24 | e[t + 1] << 16 | e[t + 2] << 8 | e[t + 3],
                            t += 4;
                    for (n = 16; n < 80; n++) {
                        var o = r[n - 3] ^ r[n - 8] ^ r[n - 14] ^ r[n - 16];
                        r[n] = 4294967295 & (o << 1 | o >>> 31)
                    }
                    var i, a, s = this.chain_[0], c = this.chain_[1], u = this.chain_[2], f = this.chain_[3], l = this.chain_[4];
                    for (n = 0; n < 80; n++) {
                        n < 40 ? n < 20 ? (i = f ^ c & (u ^ f),
                        a = 1518500249) : (i = c ^ u ^ f,
                        a = 1859775393) : n < 60 ? (i = c & u | f & (c | u),
                        a = 2400959708) : (i = c ^ u ^ f,
                        a = 3395469782);
                        o = (s << 5 | s >>> 27) + i + l + a + r[n] & 4294967295;
                        l = f,
                        f = u,
                        u = 4294967295 & (c << 30 | c >>> 2),
                        c = s,
                        s = o
                    }
                    this.chain_[0] = this.chain_[0] + s & 4294967295,
                    this.chain_[1] = this.chain_[1] + c & 4294967295,
                    this.chain_[2] = this.chain_[2] + u & 4294967295,
                    this.chain_[3] = this.chain_[3] + f & 4294967295,
                    this.chain_[4] = this.chain_[4] + l & 4294967295
                }
                ,
                e.prototype.update = function(e, t) {
                    if (null != e) {
                        void 0 === t && (t = e.length);
                        var r = t - this.blockSize
                          , n = 0
                          , o = this.buf_
                          , i = this.inbuf_;
                        while (n < t) {
                            if (0 === i)
                                while (n <= r)
                                    this.compress_(e, n),
                                    n += this.blockSize;
                            if ("string" === typeof e) {
                                while (n < t)
                                    if (o[i] = e.charCodeAt(n),
                                    ++i,
                                    ++n,
                                    i === this.blockSize) {
                                        this.compress_(o),
                                        i = 0;
                                        break
                                    }
                            } else
                                while (n < t)
                                    if (o[i] = e[n],
                                    ++i,
                                    ++n,
                                    i === this.blockSize) {
                                        this.compress_(o),
                                        i = 0;
                                        break
                                    }
                        }
                        this.inbuf_ = i,
                        this.total_ += t
                    }
                }
                ,
                e.prototype.digest = function() {
                    var e = []
                      , t = 8 * this.total_;
                    this.inbuf_ < 56 ? this.update(this.pad_, 56 - this.inbuf_) : this.update(this.pad_, this.blockSize - (this.inbuf_ - 56));
                    for (var r = this.blockSize - 1; r >= 56; r--)
                        this.buf_[r] = 255 & t,
                        t /= 256;
                    this.compress_(this.buf_);
                    var n = 0;
                    for (r = 0; r < 5; r++)
                        for (var o = 24; o >= 0; o -= 8)
                            e[n] = this.chain_[r] >> o & 255,
                            ++n;
                    return e
                }
                ,
                e
            }();
            function V(e, t) {
                var r = new W(e,t);
                return r.subscribe.bind(r)
            }
            var W = function() {
                function e(e, t) {
                    var r = this;
                    this.observers = [],
                    this.unsubscribes = [],
                    this.observerCount = 0,
                    this.task = Promise.resolve(),
                    this.finalized = !1,
                    this.onNoObservers = t,
                    this.task.then((function() {
                        e(r)
                    }
                    )).catch((function(e) {
                        r.error(e)
                    }
                    ))
                }
                return e.prototype.next = function(e) {
                    this.forEachObserver((function(t) {
                        t.next(e)
                    }
                    ))
                }
                ,
                e.prototype.error = function(e) {
                    this.forEachObserver((function(t) {
                        t.error(e)
                    }
                    )),
                    this.close(e)
                }
                ,
                e.prototype.complete = function() {
                    this.forEachObserver((function(e) {
                        e.complete()
                    }
                    )),
                    this.close()
                }
                ,
                e.prototype.subscribe = function(e, t, r) {
                    var n, o = this;
                    if (void 0 === e && void 0 === t && void 0 === r)
                        throw new Error("Missing Observer.");
                    n = U(e, ["next", "error", "complete"]) ? e : {
                        next: e,
                        error: t,
                        complete: r
                    },
                    void 0 === n.next && (n.next = H),
                    void 0 === n.error && (n.error = H),
                    void 0 === n.complete && (n.complete = H);
                    var i = this.unsubscribeOne.bind(this, this.observers.length);
                    return this.finalized && this.task.then((function() {
                        try {
                            o.finalError ? n.error(o.finalError) : n.complete()
                        } catch (e) {}
                    }
                    )),
                    this.observers.push(n),
                    i
                }
                ,
                e.prototype.unsubscribeOne = function(e) {
                    void 0 !== this.observers && void 0 !== this.observers[e] && (delete this.observers[e],
                    this.observerCount -= 1,
                    0 === this.observerCount && void 0 !== this.onNoObservers && this.onNoObservers(this))
                }
                ,
                e.prototype.forEachObserver = function(e) {
                    if (!this.finalized)
                        for (var t = 0; t < this.observers.length; t++)
                            this.sendOne(t, e)
                }
                ,
                e.prototype.sendOne = function(e, t) {
                    var r = this;
                    this.task.then((function() {
                        if (void 0 !== r.observers && void 0 !== r.observers[e])
                            try {
                                t(r.observers[e])
                            } catch (n) {
                                "undefined" !== typeof console && console.error && console.error(n)
                            }
                    }
                    ))
                }
                ,
                e.prototype.close = function(e) {
                    var t = this;
                    this.finalized || (this.finalized = !0,
                    void 0 !== e && (this.finalError = e),
                    this.task.then((function() {
                        t.observers = void 0,
                        t.onNoObservers = void 0
                    }
                    )))
                }
                ,
                e
            }();
            function z(e, t) {
                return function() {
                    for (var r = [], n = 0; n < arguments.length; n++)
                        r[n] = arguments[n];
                    Promise.resolve(!0).then((function() {
                        e.apply(void 0, r)
                    }
                    )).catch((function(e) {
                        t && t(e)
                    }
                    ))
                }
            }
            function U(e, t) {
                if ("object" !== typeof e || null === e)
                    return !1;
                for (var r = 0, n = t; r < n.length; r++) {
                    var o = n[r];
                    if (o in e && "function" === typeof e[o])
                        return !0
                }
                return !1
            }
            function H() {}
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var G = function(e, t, r, n) {
                var o;
                if (n < t ? o = "at least " + t : n > r && (o = 0 === r ? "none" : "no more than " + r),
                o) {
                    var i = e + " failed: Was called with " + n + (1 === n ? " argument." : " arguments.") + " Expects " + o + ".";
                    throw new Error(i)
                }
            };
            function $(e, t, r) {
                var n = "";
                switch (t) {
                case 1:
                    n = r ? "first" : "First";
                    break;
                case 2:
                    n = r ? "second" : "Second";
                    break;
                case 3:
                    n = r ? "third" : "Third";
                    break;
                case 4:
                    n = r ? "fourth" : "Fourth";
                    break;
                default:
                    throw new Error("errorPrefix called with argumentNumber > 4.  Need to update it?")
                }
                var o = e + " failed: ";
                return o += n + " argument ",
                o
            }
            function J(e, t, r, n) {
                if ((!n || r) && "string" !== typeof r)
                    throw new Error($(e, t, n) + "must be a valid firebase namespace.")
            }
            function K(e, t, r, n) {
                if ((!n || r) && "function" !== typeof r)
                    throw new Error($(e, t, n) + "must be a valid function.")
            }
            function q(e, t, r, n) {
                if ((!n || r) && ("object" !== typeof r || null === r))
                    throw new Error($(e, t, n) + "must be a valid context object.")
            }
            /**
 * @license
 * Copyright 2017 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
            var Y = function(e) {
                for (var t = [], r = 0, n = 0; n < e.length; n++) {
                    var o = e.charCodeAt(n);
                    if (o >= 55296 && o <= 56319) {
                        var a = o - 55296;
                        n++,
                        i(n < e.length, "Surrogate pair missing trail surrogate.");
                        var s = e.charCodeAt(n) - 56320;
                        o = 65536 + (a << 10) + s
                    }
                    o < 128 ? t[r++] = o : o < 2048 ? (t[r++] = o >> 6 | 192,
                    t[r++] = 63 & o | 128) : o < 65536 ? (t[r++] = o >> 12 | 224,
                    t[r++] = o >> 6 & 63 | 128,
                    t[r++] = 63 & o | 128) : (t[r++] = o >> 18 | 240,
                    t[r++] = o >> 12 & 63 | 128,
                    t[r++] = o >> 6 & 63 | 128,
                    t[r++] = 63 & o | 128)
                }
                return t
            }
              , Q = function(e) {
                for (var t = 0, r = 0; r < e.length; r++) {
                    var n = e.charCodeAt(r);
                    n < 128 ? t++ : n < 2048 ? t += 2 : n >= 55296 && n <= 56319 ? (t += 4,
                    r++) : t += 3
                }
                return t
            };
            t.CONSTANTS = o,
            t.Deferred = d,
            t.ErrorFactory = O,
            t.FirebaseError = w,
            t.Sha1 = M,
            t.assert = i,
            t.assertionError = a,
            t.async = z,
            t.base64 = u,
            t.base64Decode = l,
            t.base64Encode = f,
            t.contains = P,
            t.createSubscribe = V,
            t.decode = C,
            t.deepCopy = h,
            t.deepExtend = p,
            t.errorPrefix = $,
            t.getUA = v,
            t.isAdmin = R,
            t.isBrowser = _,
            t.isEmpty = L,
            t.isMobileCordova = b,
            t.isNode = y,
            t.isNodeSdk = m,
            t.isReactNative = g,
            t.isValidFormat = j,
            t.isValidTimestamp = D,
            t.issuedAtTime = k,
            t.jsonEval = N,
            t.map = x,
            t.querystring = F,
            t.querystringDecode = B,
            t.safeGet = I,
            t.stringLength = Q,
            t.stringToByteArray = Y,
            t.stringify = T,
            t.validateArgCount = G,
            t.validateCallback = K,
            t.validateContextObject = q,
            t.validateNamespace = J
        }
        ).call(this, r("c8ba"))
    }
}]);
//# sourceMappingURL=firebase-app-firebase-auth-firebase-database-firebase-messaging.469a5e9f.js.map
